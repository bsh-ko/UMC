import axios from "axios";

// 댓글 조회
export const fetchComments = async (
  lpId: string,
  page: number,
  sort: "new" | "old"
): Promise<{ comments: Comment[]; nextPage?: number }> => {
  const res = await axios.get(`http://localhost:8000/v1/lps/${lpId}/comments`, {
    params: { page, sort },
  });

  return {
    comments: res.data.data,
    nextPage: res.data.nextPage ?? undefined,
  };
};

// 댓글 작성
export const addComment = async (lpId: string, content: string): Promise<Comment> => {
  const res = await axios.post(`http://localhost:8000/v1/lps/${lpId}/comments`, {
    content,
  });
  return res.data;
};

// 댓글 수정
export const updateComment = async (lpId: string, commentId: string, content: string): Promise<Comment> => {
  const res = await axios.patch(`http://localhost:8000/v1/lps/${lpId}/comments/${commentId}`, {
    content,
  });
  return res.data;
};

// 댓글 삭제
export const deleteComment = async (lpId: string, commentId: string): Promise<void> => {
  await axios.delete(`http://localhost:8000/v1/lps/${lpId}/comments/${commentId}`);
};
