import { useNavigate, useParams } from "react-router-dom";
import { useQuery, useInfiniteQuery } from "@tanstack/react-query";
import axios from "axios";
import { useEffect, useRef, useState } from "react";
import { Lp } from "../types/lp";
import { fetchComments } from "../apis/comment";
import CommentListSkeletonList from "../components/CommentCard/CommentListSkeletonList";
import CommentList from "../components/CommentCard/CommentList";
import { useAddComment } from "../hooks/mutations/useComments"; // 댓글 작성 훅

const fetchLpById = async (id: string): Promise<Lp> => {
  const response = await axios.get(`http://localhost:8000/v1/lps/${id}`);
  return response.data.data;
};

const LpDetailPage = () => {
  const navigate = useNavigate();
  const params = useParams();
  const id = params.id!;
  const [sortOrder, setSortOrder] = useState<"new" | "old">("new");
  const [commentInput, setCommentInput] = useState("");
  const observerRef = useRef<HTMLDivElement | null>(null);

  const {
    data: lp,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["lpDetail", id],
    queryFn: () => fetchLpById(id),
  });

  const {
    data: commentPages,
    isLoading: isCommentsLoading,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = useInfiniteQuery({
    queryKey: ["comments", id, sortOrder],
    queryFn: ({ pageParam = 1 }) => fetchComments(id, pageParam, sortOrder),
    getNextPageParam: (lastPage) => lastPage.nextPage,
    initialPageParam: 1,
  });

  const addCommentMutation = useAddComment(id);

  const handleAddComment = () => {
    if (!commentInput.trim()) return;

    addCommentMutation.mutate(commentInput, {
      onSuccess: () => {
        setCommentInput("");
      },
    });
  };

  useEffect(() => {
    if (!observerRef.current || !hasNextPage) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          fetchNextPage();
        }
      },
      { threshold: 1.0 }
    );

    observer.observe(observerRef.current);
    return () => observer.disconnect();
  }, [fetchNextPage, hasNextPage]);

  if (isError || !lp) return <div>Error</div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-gray-500 rounded-2xl shadow-2xl p-10 space-y-8 text-white">
        {/* Header Section */}
        <div className="flex justify-between items-center mb-12">
          <button onClick={() => navigate(-1)} className="cursor-pointer text-2xl transition-all duration-300">
            ◀️
          </button>
          <div className="flex gap-5">
            <button className="px-3 py-1 rounded-lg hover:bg-pink-500 border">✏️</button>
            <button className="px-3 py-1 rounded-lg hover:bg-pink-500 border">🗑️</button>
            <button className="px-3 py-1 rounded-lg hover:bg-pink-500 border">❤️</button>
          </div>
        </div>

        {/* LP Detail */}
        <div className="flex flex-col items-center mb-8 space-y-6">
          <img
            src={lp.thumbnail}
            alt={lp.title}
            className="w-full md:w-96 rounded-lg shadow-xl transition-all duration-300 transform hover:scale-105"
          />
          <div className="text-center space-y-4">
            <h2 className="text-2xl font-extrabold text-gray-100">{lp.title}</h2>
            <p className="text-base text-gray-300 whitespace-pre-wrap">{lp.content}</p>
          </div>
        </div>

        {/* Comments */}
        <div className="mt-12">
          <h3 className="text-3xl font-semibold mb-6">댓글</h3>

          {/* Sort Buttons */}
          <div className="flex gap-4 mb-6">
            <button
              onClick={() => setSortOrder("new")}
              className={`px-4 py-2 rounded-lg ${sortOrder === "new" ? "bg-pink-500" : "bg-gray-700"}`}
            >
              최신순
            </button>
            <button
              onClick={() => setSortOrder("old")}
              className={`px-4 py-2 rounded-lg ${sortOrder === "old" ? "bg-pink-500" : "bg-gray-700"}`}
            >
              오래된 순
            </button>
          </div>

          {/* Comment Input */}
          <div className="mb-6">
            <textarea
              className="w-full p-4 rounded-lg text-black"
              rows={3}
              placeholder="댓글을 작성하세요..."
              value={commentInput}
              onChange={(e) => setCommentInput(e.target.value)}
            />
            <button
              onClick={handleAddComment}
              className="mt-2 px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition"
            >
              댓글 작성
            </button>
            {addCommentMutation.isError && (
              <p className="text-red-400 mt-2">댓글 작성에 실패했습니다. 로그인했는지 확인해주세요.</p>
            )}
          </div>

          {/* Comment List */}
          <div className="space-y-4">
            {isCommentsLoading ? (
              <CommentListSkeletonList count={5} />
            ) : (
              commentPages?.pages.map((page) =>
                page.comments.map((comment) => (
                  <div
                    key={comment.id}
                    className="bg-gray-800 p-6 rounded-lg shadow-md transition-transform duration-300 hover:scale-105"
                  >
                    <p className="text-gray-300 font-semibold">{comment.author}</p>
                    <p className="text-gray-400 text-sm mb-2">{new Date(comment.createdAt).toLocaleDateString()}</p>
                    <p className="text-gray-300">{comment.content}</p>
                  </div>
                ))
              )
            )}
            {isFetchingNextPage && <CommentListSkeletonList count={2} />}
            <div ref={observerRef} className="h-10" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default LpDetailPage;
