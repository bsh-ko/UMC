const NotFoundPage = () => {
    return (
        <div className="text-red-600 text-5xl">
            Error Occurred
        </div>
    );
};

export default NotFoundPage
